// fill in your db credentials
exports.config = {
  host: "localhost",
  user: "root",
  password: "Adrian1500",
  database: "coen161"
};