const bodyParser = require('body-parser');
const cookieSession = require('cookie-session');
const crypto = require('crypto');
const express = require('express');
const mysql = require('mysql');

const app = express();
const con = mysql.createConnection({
  database: 'coen161',
  password: 'Adrian1500',
  user: 'root',
});
const port = 3000;

// We only need to connect to the DB once.
// This allows us to query the DB in any 
// route. Don't close the connection in a
// route otherwise the queries will error.
con.connect(err => {
  if (err) throw err;

  console.log('Connected to the DB!');
});

app.use(bodyParser.json());

app.use(cookieSession({
  name: 'session',
  keys: ['key1', 'key2'],
}));

// create unique id on session, if it doesn't exist
app.use((req, res, next) => {
  if (!req.session.id) {
    req.session.id = crypto.randomBytes(16).toString("hex");
  }
  
  next();
});

// serve React client app assets
app.use(express.static('client/build'));

// Enter your solution below

app.get('/todos', function(req, res) {
  let sql = "SELECT * FROM Todos WHERE sessionId=\"" + req.session.id + "\";";
  con.query(sql, function(err, data) {
    if (err) { 
      throw err;
    }
    let obj = {};
    let objList = [];
    for (let i = 0; i < data.length; i++) {
      obj = {
        completed: data[i].completed,
        description: data[i].description,
        id: data[i].id
      };

      objList.push(obj);
    }

    res.writeHead(200, {"Content-Type": "application/json"});
    res.end(JSON.stringify(objList));
  });
});

app.post('/todo', function(req, res) {
  let sql = "INSERT INTO Todos (description, sessionId) VALUES (\"" + req.body.todo + "\", \"" + req.insertId + "\");"; 
  con.query(sql, function(err, data) {
    if (err) {
      throw err;
    }

    let obj = {
      description: req.body.todo,
      id: req.insertId
    };

    res.send(JSON.stringify(obj));
  });
});


app.put('/todo/:id', function(req, res) {
  let sql = "UPDATE Todos SET completed=" + req.body.completed + " WHERE sessionId=\"" + req.params.id + "\";";
  con.query(sql, function(err) {
    if (err) {
      throw err;
    }
    res.end();
  });
});

app.put('/todo/:id', function(req, res) {
  let sql = "DELETE FROM Todos WHERE id=\"" + req.params.id + "\";";
  con.query(sql, function(err) {
    if (err) { 
      throw err;
    }
    res.end();
  });
});

app.listen(port, () => {
  console.log('To-Do app started on port ' + port);
});
