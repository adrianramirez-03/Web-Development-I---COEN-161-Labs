const fs = require('fs');

exports.handleTodoList = function(req, res, session) {
  switch(req.method) {
    case "GET":
      var arr = [];

      fs.readFile('./sessions/' + session.id, function(err, data) {
        if(err) {
            res.writeHead(500, {'Content-Type': 'text/html'});
            return res.end("500 Internal Server Error");
        }

        session = JSON.parse(data);

        for(let i = 0; i < session.todoList.length; i++) {
          arr.push({
            id: i,
            description: session.todoList[i]
          });
        }

        res.writeHead(200, {'Content-Type': 'application/json'});
        res.end(JSON.stringify(arr));
      });

    break;
    case "POST":
      if(session.todoList == undefined) {
        session.todoList = new Array();
      }

      convertRequest(req, function(data){
        session.todoList.push(data.todo)
        console.log(session.todoList);
        fs.writeFile('./sessions/' + session.id, JSON.stringify(session), function(err) {
          if(err) {
            res.writeHead(500, {'Content-Type': 'text/html'});
            return res.end("500 Internal Server Error");
          }
          res.writeHead(200, 'OK');
          res.end();
        });
      });

    break;
    default:
      res.writeHead(405, {'Allow': 'GET, POST'});
      res.end("Not Allowed");
  }
};

/*
  converts the HTTP POST request body into a JSON object
*/
function convertRequest(req, callback) {
  let data = "";
  req.on('data', chunk => {
    data += chunk.toString();
  });
  req.on('end', () => {
    callback(JSON.parse(data));
  });
}